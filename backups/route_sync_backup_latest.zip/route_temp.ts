import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
const supabase = createClient(supabaseUrl, supabaseKey);

export async function GET() {
  try {
    // 💡 대표님이 제공해주신 일반 인증키 적용
    const apiKey = 'cc00394f965565fe175b2849c1fea074db876e6d3dfffb5b5a63bf04c917f489';
    let pageNo = 1;
    const numOfRows = 100;
    let allDrugs: any[] = [];
    let hasMore = true;

    console.log("========== [식약처 데이터 동기화 시작] ==========");

    while (hasMore) {
      console.log(`[페이지 ${pageNo}] 데이터 요청 중...`);
      const apiUrl = `https://apis.data.go.kr/1471000/DrbEasyDrugInfoService/getDrbEasyDrugList?serviceKey=${apiKey}&pageNo=${pageNo}&numOfRows=${numOfRows}&type=json`;

      const res = await fetch(apiUrl);
      const text = await res.text();

      if (!res.ok || text.includes('Unauthorized') || text.includes('SERVICE_ERROR') || text.includes('<')) {
        console.error(`[페이지 ${pageNo}] 정부 서버 에러 발생!`, text.substring(0, 500));
        return NextResponse.json({
          success: false,
          message: `페이지 ${pageNo} 가져오기 실패: 정부 서버 인증 또는 통신 장애가 발생했습니다.`,
          error: text.substring(0, 300)
        });
      }

      const data = JSON.parse(text);
      const drugs = data.body?.items;
      const totalCount = data.body?.totalCount || 0;

      if (!drugs || drugs.length === 0) {
        console.log(`[페이지 ${pageNo}] 더 이상 가져올 데이터가 없습니다.`);
        hasMore = false;
        break;
      }

      allDrugs = allDrugs.concat(drugs);
      console.log(`[페이지 ${pageNo}] 완료 - 수신: ${drugs.length}개 / 현재 누적: ${allDrugs.length}개 (전체: ${totalCount}개)`);

      // 전체 카운트에 도달했거나 수신된 데이터 개수가 요청수보다 적으면 종료
      if (allDrugs.length >= totalCount || drugs.length < numOfRows) {
        hasMore = false;
        break;
      }

      pageNo++;

      // 무한 루프 방지 안전장치 (최대 60페이지 = 6,000개)
      if (pageNo > 60) {
        console.warn("[경고] 안전을 위해 최대 페이지 제한(60페이지)에 도달하여 중단합니다.");
        break;
      }
    }

    console.log(`[동기화 완료] 총 수집된 데이터: ${allDrugs.length}개`);

    if (allDrugs.length === 0) {
      return NextResponse.json({ success: false, message: '가져온 데이터가 전혀 없습니다.' });
    }

    // Supabase items 테이블 형식에 맞게 데이터 매핑
    const insertData = allDrugs.map((drug: any) => ({
      name: drug.itemName,
      category: '의약품',
      current_stock: 0,
      safety_stock: 10
    }));

    console.log(`[Supabase] ${insertData.length}개 데이터 일괄(Bulk Insert) 삽입 중...`);
    
    // Supabase Bulk Insert 실행
    const { error } = await supabase.from('items').insert(insertData);
    
    if (error) {
      console.error("[Supabase 에러]", error);
      throw error;
    }

    console.log("[Supabase] 일괄 삽입 성공!");
    console.log("==================================================");

    return NextResponse.json({
      success: true,
      message: `총 ${insertData.length}개 품목 동기화 및 일괄 삽입 성공!`,
      totalCount: insertData.length
    });

  } catch (error: any) {
    console.error("동기화 전체 에러:", error);
    return NextResponse.json({
      success: false,
      error: '동기화 중 시스템 에러가 발생했습니다.',
      details: error.message || error
    });
  }
}